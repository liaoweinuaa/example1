#pragma once
//This file specifies parameters such as the computational domain, number of grids, time step, etc.

//computational domain
const double xmin = -2;
const double xmax = 2;
const double ymin = -2;
const double ymax = 2;

//number of grids for rough computation
const int Nrx = 26;
const int Nry = 26;

//grid size for rough computation
const double gridrx = (xmax - xmin) / (Nrx - 1);
const double gridry = (ymax - ymin) / (Nry - 1);

//number of grids for fine tuning
const int Nfx = 101;
const int Nfy = 101;

//grid size for fine tuning
const double gridfx = (xmax - xmin) / (Nfx - 1);
const double gridfy = (ymax - ymin) / (Nfy - 1);

//time step size
const double dt = 0.02;

//range of control input
const double amin = -1;
const double amax = 1;
const int Na = 21;
const double grida= (amax - amin) / (Na - 1);

//system state
struct State
{
	double x;
	double y;
};

struct StateIndex
{
	int ix;
	int iy;
};


const double gamma = 0.25;