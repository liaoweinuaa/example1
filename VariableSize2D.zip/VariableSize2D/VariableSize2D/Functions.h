#pragma once
#include <string>
using namespace std;

void Func_Init();
void Func_RecursionR();
void Func_RecursionF();
void Func_Upsampling();
void Func_SavaData(string filename0, string filename1);