#include "Constants.h"
#include <iostream>
#include <string>
#include <mutex>
#include <thread>
#include <math.h>
//#include "Functions.h"
#include <fstream>

using namespace std;

//The following two-dimensional array is used in the rough computation phase to save the values of the value function at the grid points
extern double(*Arr_StateValueR)[Nry];
extern double(*Arr_StateValueNewR)[Nry];
extern State(*Arr_StateR)[Nry];// Used to save the state of each grid point representation (For rough computation)
//The following two-dimensional array is used in the fine tuning phase to save the values of the value function at the grid points
extern double(*Arr_StateValueF)[Nfy];
extern double(*Arr_StateValueNewF)[Nfy];
extern State(*Arr_StateF)[Nfy];// Used to save the state of each grid point representation (For fine tuning)



void Func_Init()
{
	memset(Arr_StateValueR, 0, sizeof(double) * Nrx * Nry);
	memset(Arr_StateValueNewR, 0, sizeof(double) * Nrx * Nry);
	// initial Arr_StateR
	for (int i = 0; i < Nrx; i++)
	{
		for (int j = 0; j < Nry; j++)
		{
			// The state at grid point [i][j]
			Arr_StateR[i][j].x = xmin + gridrx * i; 
			Arr_StateR[i][j].y = ymin + gridry * j;
		}
	}

	memset(Arr_StateValueF, 0, sizeof(double) * Nfx * Nfy);
	memset(Arr_StateValueNewF, 0, sizeof(double) * Nfx * Nfy);
	// initial Arr_StateR
	for (int i = 0; i < Nfx; i++)
	{
		for (int j = 0; j < Nfy; j++)
		{
			// The state at grid point [i][j]
			Arr_StateF[i][j].x = xmin + gridfx * i;
			Arr_StateF[i][j].y = ymin + gridfy * j;
		}
	}
}

// Determine if a state is in the target set: |y|<=0.5
bool Func_IsInTargetSet(State s)
{
	if (abs(s.y) <= 0.5)
	{
		return true;
	}
	else
	{
		return false;
	}
}

// Modified dynamical system, see Eq. (7) in our paper
// Input: current state s, control input a
// Output: Next state
State Func_Transition(State s, double a)
{
	if (Func_IsInTargetSet(s))
	{
		return s;
	}

	double x = s.x;
	double y = s.y;

	double dotx = 0;
	if (y >= 0)
	{
		dotx = -1;
	}
	else
	{
		dotx = 1;
	}

	double doty = - x + a;


	double dotdotx = 0;
	double dotdoty = -1 * dotx;

	// State of the next moment
	double newx = x + dotx * dt + 0.5 * dotdotx * dt * dt;
	double newy = y + doty * dt + 0.5 * dotdoty * dt * dt;

	// When the next state falls outside the computational domain, clip it into the computational domain
	if (newx >= xmax)
	{
		newx = xmax - 0.0001;
	}

	if (newx <= xmin)
	{
		newx = xmin + 0.0001;
	}

	if (newy >= ymax)
	{
		newy = ymax - 0.0001;
	}

	if (newy <= ymin)
	{
		newy = ymin + 0.0001;
	}

	return State{
		newx,newy
	};
}

// Binary linear interpolation function on 2D array Arr_StateValueR
// Input: state s0
// Putput: the value of the interpolation function at s0
double Func_InterPolationR(State s0)
{
	if (Func_IsInTargetSet(s0))
	{
		return 0;
	}
	double ix_double = ((s0.x - xmin) / gridrx);
	double iy_double = ((s0.y - ymin) / gridry);

	int ix = int(ix_double);
	int iy = int(iy_double);

	double v00 = Arr_StateValueR[ix][iy];
	double v01 = Arr_StateValueR[ix][iy + 1];
	double v10 = Arr_StateValueR[ix + 1][iy];
	double v11 = Arr_StateValueR[ix + 1][iy + 1];

	double dx0 = ix_double - ix;
	double dx1 = 1 - dx0;
	double dy0 = iy_double - iy;
	double dy1 = 1 - dy0;

	double V00 = dx0 * dy0;
	double V01 = dx0 * dy1;
	double V10 = dx1 * dy0;
	double V11 = dx1 * dy1;

	return (v00 * V11 + v01 * V10 + v10 * V01 + v11 * V00);
}


// Binary linear interpolation function on 2D array Arr_StateValueF
// Input: state s0
// Putput: the value of the interpolation function at s0
double Func_InterPolationF(State s0)
{
	if (Func_IsInTargetSet(s0))
	{
		return 0;
	}
	double ix_double = ((s0.x - xmin) / gridfx);
	double iy_double = ((s0.y - ymin) / gridfy);

	int ix = int(ix_double);
	int iy = int(iy_double);

	double v00 = Arr_StateValueF[ix][iy];
	double v01 = Arr_StateValueF[ix][iy + 1];
	double v10 = Arr_StateValueF[ix + 1][iy];
	double v11 = Arr_StateValueF[ix + 1][iy + 1];

	double dx0 = ix_double - ix;
	double dx1 = 1 - dx0;
	double dy0 = iy_double - iy;
	double dy1 = 1 - dy0;

	double V00 = dx0 * dy0;
	double V01 = dx0 * dy1;
	double V10 = dx1 * dy0;
	double V11 = dx1 * dy1;

	return (v00 * V11 + v01 * V10 + v10 * V01 + v11 * V00);
}

//Modified running cost function, see Eq. (6) in our paper
double Func_RunningCost(State s0, State s1, double u)
{
	if (Func_IsInTargetSet(s0))
	{
		return 0;
	}

	return 1;
}

// Compute the value of a state under optimal input (rough computation)
double Func_StateValueR(State s0)
{
	double minvalue = 1000000;
	for (int i = 0; i < Na; i++)
	{
		double a = amin + i * grida;

		State snew = Func_Transition(s0, a);
		double snewvalue = Func_InterPolationR(snew);
		// I wrote the calculations for expressions gamma^dt and (gamma^dt-1)/ln(gamma) directly here
		// You can modify the values here according to dt and gamma.
		double value = Func_RunningCost(s0, snew, a) * 0.01972528 + 0.972655 * snewvalue;

		if (value < minvalue)
		{
			minvalue = value;
		}

	}
	return minvalue;
}

// Compute the value of a state under optimal input (fine tuning)
double Func_StateValueF(State s0)
{
	double minvalue = 1000000;
	for (int i = 0; i < Na; i++)
	{
		double a = amin + i * grida;

		State snew = Func_Transition(s0, a);
		double snewvalue = Func_InterPolationF(snew);
		//double value = Func_RunningCost(s0, snew, a) * ((pow(gamma, dt) / log(gamma))) + pow(gamma, dt) * snewvalue;
		double value = Func_RunningCost(s0, snew, a) * dt + 0.972655 * snewvalue;

		if (value < minvalue)
		{
			minvalue = value;
		}

	}
	return minvalue;
}

// Upsampling
void Func_Upsampling()
{
	for (int i = 0; i < Nfx; i++)
	{
		for (int j = 0; j < Nfy; j++)
		{
			Arr_StateValueF[i][j] = Func_InterPolationR(Arr_StateF[i][j]);
		}
	}
}

// Recursion for rough computation phase
void Func_RecursionR()
{
	for (int i = 0; i < Nrx; i++)
	{
		for (int j = 0; j < Nry; j++)
		{
			Arr_StateValueNewR[i][j] = Func_StateValueR(Arr_StateR[i][j]);
		}
	}
	memcpy(Arr_StateValueR, Arr_StateValueNewR, sizeof(double) * Nrx * Nry);
}

// Recursion for fine tuning phase
void Func_RecursionF()
{
	for (int i = 0; i < Nfx; i++)
	{
		for (int j = 0; j < Nfy; j++)
		{
			Arr_StateValueNewF[i][j] = Func_StateValueF(Arr_StateF[i][j]);
		}
	}
	memcpy(Arr_StateValueF, Arr_StateValueNewF, sizeof(double) * Nfx * Nfy);
}


void Func_SavaData(string filename0, string filename1)
{
	ofstream ofs0,ofs1;
	ofs0.open(filename0);
	for (int i = 0; i < Nrx; i ++)
	{
		for (int j = 0; j < Nry; j ++)
		{
			ofs0 << Arr_StateValueR[i][j];
			if (j!=Nry-1)
			{
				ofs0 << ",";
			}
		}
		ofs0 << endl;
	}
	ofs0.close();

	ofs1.open(filename1);
	for (int i = 0; i < Nfx; i++)
	{
		for (int j = 0; j < Nfy; j++)
		{
			ofs1 << Arr_StateValueF[i][j];
			if (j != Nfy - 1)
			{
				ofs1 << ",";
			}
		}
		ofs1 << endl;
	}
	ofs1.close();
}